# import pandas as pd
# # 从Excel文件读取数据
# excel_file_path = '/home/zl/ex1.xlsx'
# # 替换为实际的Excel文件路径
# df = pd.read_excel(excel_file_path)
# # 显示数据框的前几行
# print(df.head())
