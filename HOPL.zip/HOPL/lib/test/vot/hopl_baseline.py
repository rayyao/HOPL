import os
import sys
env_path = os.path.join(os.path.dirname(__file__), '../../..')
if env_path not in sys.path:
    sys.path.append(env_path)
from HOPL.lib.test.vot.hopl_class import run_vot_exp
os.environ['CUDA_VISIBLE_DEVICES'] = '0'


run_vot_exp('hopl', 'shaw_rgbt', vis=False, out_conf=True, channel_type='rgbt')
