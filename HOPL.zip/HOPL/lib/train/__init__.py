from viptnew.lib.train.admin.multigpu import MultiGPU
