import torch
checkpoint=torch.load('/home/zl/TwoPrompt/HOPL/output/checkpoints/train/hopl/deep_rgbt/ViPTrack_ep0021.pth.tar')
state_dict=checkpoint['net']
print(state_dict)
for name,param in state_dict.named_parameters():
    print(name,param.requires_grad)
#
# for name,param in state_dict.items():
#     if not param.requires_grad:
#         print(f'Parameter"{name}"is frozen')
#     else:
#         print(f'Parameter"{name}"is trainable')